# COMP2068-MongoDemo

A MongoDB Demo Project for COMP2068 @ Georgian College
