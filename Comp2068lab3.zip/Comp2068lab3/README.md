# comp2068lab3
Express app using the express-generator for COMP2068 Lab 3
